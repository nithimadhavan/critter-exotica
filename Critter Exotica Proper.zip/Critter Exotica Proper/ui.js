const list = document.querySelector('.list')
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('.form');
});
const rendertable=(data,id)=>{
    const html=`<table class="list" id="storeList" data-id="${id}">
    <thead>
        <tr>
            <th>${data.name}</th>
            <th>${data.variant}</th>
        </tr>
    </thead>
    <tbody>

    </tbody>
</table>`;
    list.innerHTML += html;
}