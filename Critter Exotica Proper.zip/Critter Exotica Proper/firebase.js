// For Firebase JS SDK v7.20.0 and later, measurementId is optional
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js";
import { getFirestore, collection, enableIndexedDbPersistence, onSnapshot, deleteDoc, doc , addDoc, updateDoc} from "https://www.gstatic.com/firebasejs/9.13.0/firebase-firestore.js";
const firebaseConfig = {
    apiKey: "AIzaSyBGw5hZiGoYIVbzpgadnnTMmBWrp7cyAEU",
    authDomain: "exotic-pet-kn.firebaseapp.com",
    projectId: "exotic-pet-kn",
    storageBucket: "exotic-pet-kn.appspot.com",
    messagingSenderId: "1098279028095",
    appId: "1:1098279028095:web:3fb9ffa9221af14eb5c64a",
    measurementId: "G-TQV95F8J4T"
  };
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);
  const locationsCol = collection(db,'Pet');
  
  enableIndexedDbPersistence(db)
  .catch((err) => {
      console.log(err);
      if (err.code == 'failed-precondition') {
        console.log("Multiple tabs open,use only one tab");
      } else if (err.code == 'unimplemented') {
          console.log("IndexedDB not supported");
      }
  });
  
  const ss = onSnapshot(locationsCol,snapshot =>{
    snapshot.docChanges().forEach(change =>{
        console.log(change);
        console.log(change.doc.data(),change.doc.id);
        if(change.type === 'added'){
            rendertable(change.doc.data(),change.doc.id);
        }
        // if(change.type === 'removed'){
        //     removeLocation(change.doc.id);
        // }
    })
})

const form = document.querySelector('form');
form.addEventListener('submit',evt=>{
  evt.preventDefault();
  const location = 
  {
    petname: form.petname.value,
    variant: form.variant.value,
    Availability : form.Availability.value
  };
  addDoc(locationsCol,location).then(data=>{
    console.log(data);
    alert("New data '"+location.petname + "'added with id:"+data.id);
  })
  form.petname.value='';
  form.variant.value='';
  

});