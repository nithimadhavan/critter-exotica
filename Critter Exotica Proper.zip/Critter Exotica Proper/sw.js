const staticCacheName = 'site-static-v2';
const dynamicCacheName = 'site-dynamic-v2';
const assets = [
    '/',
    '/index.html',
    'style.css',
    'script.js',
    'jungle.jpg',
    'app.js'
    
];
self.addEventListener('install',evt=>{
    console.log("SW Installed",evt);
    evt.waitUntil(
        caches.open(staticCacheName).then(cache=>{
            cache.addAll(assets);
        })
   )
   self.skipWaiting();
})

self.addEventListener('activate',(evt)=>{
    console.log("SW Activated",evt);
    caches.keys().then(keys=>{
        keys.forEach(key=>{
            if(key!==staticCacheName && key!== dynamicCacheName){
                caches.delete(key);
            }
        })
    })
})
self.addEventListener('fetch',(evt)=>{
    console.log("fetched data",evt);
    if(evt.request.url.indexOf('firestore.googleapis.com'|| 'firebase-firestore' || 'firebase')=== -1){
        evt.respondWith(
            caches.match(evt.request).then(cacheRes=>{
                return cacheRes || fetch(evt.request).then(fetchRes=>{
                    caches.open(dynamicCacheName).then(cache=>{
                        cache.put(evt.request,fetchRes.clone())
                        return fetchRes;
                    })
                })
            })
        )
    }

})